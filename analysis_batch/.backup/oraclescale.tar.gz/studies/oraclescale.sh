# source activate ddpg
# MountainCarContinuous-v0 Pendulum-v0 LunarLanderContinuous-v2 BipedalWalker-v2
ENVS=( "MountainCarContinuous-v0" "Pendulum-v0" )
STUDY=$(basename $0 | head -c -4)
DATE=$(date +%d%m%y%H%M)
APPENDIX=""
FILE="csv/$STUDY$APPENDIX.csv"

# Check if file is new
echo Saving results to $FILE
if [ -f $FILE ]; then echo "Beware for overwriting!"; exit 1; fi

# If this header is not matching in myddpg.py, results will be corrupt
echo "Environment,Seed,MultiHead,Num_heads,Source,Exploration,Average,Episode,Reward,Gain,Feedback,Autonomy" > $FILE

for env in "${ENVS[@]}"; do
    while read seed; do
        python myddpg.py --random-seed $seed --env $env \
        --feedback oracle --scale 0.6 --csvlines \
        | grep CSVLINE | cut -c 9- >> csv/subfiles/$STUDY.$env.$seed.6.csv 2>/dev/null &

        python myddpg.py --random-seed $seed --env $env \
        --feedback oracle --scale 0.8 --csvlines \
        | grep CSVLINE | cut -c 9- >> csv/subfiles/$STUDY.$env.$seed.8.csv 2>/dev/null &

        python myddpg.py --random-seed $seed --env $env \
        --feedback oracle --scale 1 --csvlines \
        | grep CSVLINE | cut -c 9- >> csv/subfiles/$STUDY.$env.$seed.10.csv 2>/dev/null &

        python myddpg.py --random-seed $seed --env $env \
        --feedback oracle --scale 1.2 --csvlines \
        | grep CSVLINE | cut -c 9- >> csv/subfiles/$STUDY.$env.$seed.12.csv 2>/dev/null &

        python myddpg.py --random-seed $seed --env $env \
        --feedback oracle --scale 1.4 --csvlines \
        | grep CSVLINE | cut -c 9- >> csv/subfiles/$STUDY.$env.$seed.14.csv 2>/dev/null &

        python myddpg.py --random-seed $seed --env $env \
        --feedback oracle --scale 1.6 --csvlines \
        | grep CSVLINE | cut -c 9- >> csv/subfiles/$STUDY.$env.$seed.16.csv 2>/dev/null &

		wait
    done < studies/seeds.txt
done
cat csv/subfiles/$STUDY.$DATE.* >> $FILE
chmod -w $FILE

Backup current work
conda list --export > conda_env.txt
tar -cf .backup/$STUDY.tar.gz $FILE *.py studies/$STUDY.sh conda_env.txt
rm conda_env.txt 
git add -f .backup/$STUDY.tar.gz; git add csv/*
git commit -m "Automatic commit for study '$STUDY', $(date)"
git pull; git push

echo Done
