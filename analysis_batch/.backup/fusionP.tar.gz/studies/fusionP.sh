# MountainCarContinuous-v0 Pendulum-v0 LunarLanderContinuous-v2 BipedalWalker-v2
ENVS=( "Pendulum-v0" )
STUDY=$(basename $0 | head -c -4)
DATE=$(date +%d%m%y%H%M)
APPENDIX="dos"
FILE="csv/$STUDY$APPENDIX.csv"

# Check if file is new
echo Saving results to $FILE
if [ -f $FILE ]; then echo "Beware for overwriting!"; exit 1; fi

python -u myddpg.py --header | grep --line-buffered Environment & $(sleep 15; kill %1) > $FILE

export MYDDPG_INVAR=0.2    
export MYDDPG_HFVAR=0.01   # default .001
export MYDDPG_ACTLR=0.00002 # default .0001
export MYDDPG_CRTLR=0.001   # default .001

for env in "${ENVS[@]}"; do
    while read seed; do

        python -u myddpg.py --random-seed $seed --env $env \
        --actor-lr $MYDDPG_ACTLR --critic-lr $MYDDPG_CRTLR | tee csv/subfiles/$STUDY\_$DATE\_$env\_$seed.csv &

    done < studies/seeds.txt
done
wait

cat csv/subfiles/$STUDY\_$DATE* >> $FILE
chmod -w $FILE

# Backup current work
conda list --export > conda_env.txt
tar -cf .backup/$STUDY.tar.gz $FILE *.py studies/$STUDY.sh conda_env.txt
rm conda_env.txt 
git add -f .backup/$STUDY.tar.gz; git add csv/*
git commit -m "Automatic commit for study '$STUDY', $(date)"

echo Done
