import matplotlib.pyplot as plt
import seaborn as sns
import pandas as pd

plt.style.use('seaborn')

# Colums: Environment, Episode, Reward, Seed, MultiHead, Num_heads, Feedback

			# Title 				dataset 		hue 			style 			n
studies = [\
			['DDPG vs MultiHead', 	'ddpg_vs_mh', 	'MultiHead', 	'MultiHead', 	'10'],
			['Number of Heads', 	'num_heads', 	'Num_heads', 	None,			'5']
			]

for study in studies:
	results = pd.read_csv('csv/'+study[1]+'.csv')
	sns.lineplot(x='Episode', y='Reward', data=results, hue=study[2], style=study[3])
	plt.title(study[0]+' (Pendulum-v0), n='+study[4])
	plt.savefig('graphics/' + study[0] +'.pdf')
	plt.show()
