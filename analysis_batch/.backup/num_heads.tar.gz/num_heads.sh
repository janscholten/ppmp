ENVS=( "Pendulum-v0" )
REPS=5
STUDY="num_heads"
STDARGS="--csvlines --max-episodes 150 --multihead"
TS="" #_$(date +%d%m%y%H%M)
FILE="csv/$STUDY$TS.csv"

# Check if file is new
echo $FILE
if [ -f $FILE ]; then
    echo "Beware for overwriting!"
    exit 1
fi

# If this header is not matching in myddpg.py, results will be corrupt
echo "Environment,Episode,Reward,Seed,MultiHead,Num_heads,Feedback" > $FILE

for env in "${ENVS[@]}"; do
    for (( i = 0; i < $REPS; i++ )); do
    	seed=$(date +%N)
    	for ii in 1 2 4 6 8 10; do
	    	echo -e "\n\nStarting iteration $i-$ii/$REPS in $env"
		    python myddpg.py $STDARGS \
		    --random-seed $seed --env $env --num-heads $ii\
	    	| grep CSVLINE | cut -c 9- >> $FILE
    	done
    done
done

chmod -w $FILE
python plot.py
