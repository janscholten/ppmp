ENVS=( "MountainCarContinuous-v0" )
REPS=10
STDARGS="--csvlines --max-episodes 200"

STUDY=$(basename $0 | head -c -4)_mc
TS=""
TS=_$(date +%d%m%y%H%M)
FILE="csv/$STUDY$TS.csv"

# Check if file is new
echo Saving results to $FILE
if [ -f $FILE ]; then
    echo "Beware for overwriting!"
    exit 1
fi

# Don't fall asleep
if whoami="jan"; then
    sudo systemctl mask sleep.target suspend.target hibernate.target hybrid-sleep.target
    echo "Hi jan. Your laptop will not hibernate until I'm done"
fi

# If this header is not matching in myddpg.py, results will be corrupt
echo "Environment,Episode,Reward,Seed,MultiHead,Num_heads,Feedback,Exploration,KalmanGain" > $FILE

for env in "${ENVS[@]}"; do
    for (( i = 0; i < $REPS; i++ )); do
    	seed=$(date +%N)

        # No OU-noise & no multihead
        python myddpg.py $STDARGS \
        --random-seed $seed --env $env \
            | grep CSVLINE | cut -c 9- >> $FILE

	    # No OU-noise & multihead
        python myddpg.py $STDARGS \
        --random-seed $seed --env $env --multihead \
            | grep CSVLINE | cut -c 9- >> $FILE

        # OU-noise & no multihead
        python myddpg.py $STDARGS \
	    --random-seed $seed --env $env --exploration-noise OU \
            | grep CSVLINE | cut -c 9- >> $FILE

	    # OU-noise & multihead
        python myddpg.py $STDARGS \
	    --random-seed $seed --env $env --multihead --exploration-noise OU \
	    	| grep CSVLINE | cut -c 9- >> $FILE

    	echo -e "Iteration $i of $($REPS*3*2) is finished: \t $env"
    done
done

chmod -w $FILE

# Backup current work
conda list --export > conda_env.txt
tar -cf .backup/$STUDY.tar.gz $FILE *.py oracles/ studies/$STUDY.sh conda_env.txt
rm conda_env.txt
git add -f .backup/$STUDY.tar.gz
git commit -m "Automatic commit for study '$STUDY', $(date)"

# Allow hibernation again
if whoami="jan"; then
    sudo systemctl unmask sleep.target suspend.target hibernate.target hybrid-sleep.target
fi

echo Done!