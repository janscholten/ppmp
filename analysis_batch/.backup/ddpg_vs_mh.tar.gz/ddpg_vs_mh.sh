ENVS=( "Pendulum-v0" )
REPS=10
STUDY="ddpg_vs_mh"
STDARGS="--csvlines --max-episodes 200"
TS="" #_$(date +%d%m%y%H%M)
FILE="csv/$STUDY$TS.csv"

# Check if file is new
echo Saving results to $FILE
if [ -f $FILE ]; then
    echo "Beware for overwriting!"
    exit 1
fi

echo "Environment,Episode,Reward,Seed,MultiHead,Num_heads,Feedback" > $FILE

for env in "${ENVS[@]}"; do
    for (( i = 0; i < $REPS; i++ )); do
    	seed=$(date +%N)
	    python myddpg.py $STDARGS \
	    --random-seed $seed --env $env \
	    	| grep CSVLINE | cut -c 9- >> $FILE

    	seed=$(date +%N)
	    python myddpg.py $STDARGS \
	    --random-seed $seed --env $env --multihead \
	    	| grep CSVLINE | cut -c 9- >> $FILE
    	echo "Iteration $i/$REPS in $env is finished"
    done
done

chmod -w $FILE
python plot.py
