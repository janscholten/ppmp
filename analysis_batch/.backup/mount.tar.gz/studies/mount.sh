ENVS=( "MountainCarContinuous-v0")
REPS=10
STDARGS="--csvlines --max-episodes 700"

source activate ddpg

STUDY=$(basename $0 | head -c -4)
TS=""
TS=_$(date +%d%m%y%H%M)
FILE="csv/$STUDY$TS.csv"
FILE1=csv/subfiles/$STUDY$TS.1.csv
FILE2=csv/subfiles/$STUDY$TS.2.csv
FILE3=csv/subfiles/$STUDY$TS.3.csv
SEEDFILE="studies/$STUDY.seeds.txt"
> $SEEDFILE.txt

# Check if file is new
echo Saving results to $FILE1
if [ -f $FILE1 ]; then
    echo "Beware for overwriting!"
    exit 1
fi

# Don't fall asleep
if [ $(whoami) = "jan" ]; then
    sudo systemctl mask sleep.target suspend.target hibernate.target hybrid-sleep.target
    echo "Hi jan. Your laptop will not hibernate until I'm done"
fi

# If this header is not matching in myddpg.py, results will be corrupt
echo "Environment,Seed,MultiHead,Num_heads,Feedback,Exploration,Average,Episode,Reward,KalmanGain" > $FILE

for env in "${ENVS[@]}"; do
    for (( i = 0; i < $REPS; i++ )); do
    	seed=$(date +%N)
        echo $seed >> $SEEDFILE

        python ../reference_ddpg/csvddpg.py --random-seed $seed --env $env --max-episodes 700 \
            | grep CSVLINE | cut -c 9- >> $FILE1 2>/dev/null &

        python myddpg.py $STDARGS \
        --random-seed $seed --env $env --average \
            | grep CSVLINE | cut -c 9- >> $FILE2 2>/dev/null &

        python myddpg.py $STDARGS \
        --random-seed $seed --env $env \
            | grep CSVLINE | cut -c 9- >> $FILE3 2>/dev/null

    	echo -e "Iteration $i is finished: \t $env" >> msg.txt
    done
done

wait
cat $FILE1 $FILE2 $FILE3 >> $FILE
chmod -w $FILE $FILE1 $FILE2 $FILE3

# Backup current work
conda list --export > conda_env.txt
tar -cf .backup/$STUDY.tar.gz $FILE $FILE1 $FILE2 $FILE3 *.py studies/$STUDY.sh conda_env.txt $SEEDFILE
rm conda_env.txt
git add -f .backup/$STUDY.tar.gz
git add $FILE $FILE1 $FILE2 $FILE3 $SEEDFILE
git commit -m "Automatic commit for study '$STUDY', $(date)"
git pull
git push

# Allow hibernation again
if [ $(whoami) = "jan" ]; then
    sudo systemctl unmask sleep.target suspend.target hibernate.target hybrid-sleep.target
fi

echo Done
