import tensorflow as tf
import numpy as np
import os, shutil, tflearn, pickle
from tensorflow.python.saved_model import tag_constants

from actor_networks import MultiHeadActor, DefaultActor, MultiHeadActorNoAverage

with tf.Session() as sess:

	# tf.set_random_
	if 0:
		actor = DefaultActor(sess, 
			state_dim	= 2,
			action_dim	= 1,
			action_bound=[2.],
            learning_rate=0.002, tau=0.002, batch_size=64)
	else:
		actor = MultiHeadActorNoAverage(sess, 
		# actor = MultiHeadActor(sess, 
			state_dim	= 2,
			action_dim	= 1,
			action_bound=np.array([[-1.], [1.]]),
	        learning_rate=0.002, tau=0.002, batch_size=64, k=3)		

	sess.run(tf.global_variables_initializer())
	# writer = tf.summary.FileWriter(args['summary_dir'], sess.graph)

	# Initialize target network weights
	actor.update_target_network()

	s = np.array([[1,2]])
	# , [1,2], [3,4], [3,4]])
	# print('state:', s, '\n')

	action = actor.predict(s)
	# mean, variance = actor.policy(s)
	# target = actor.predict_target(s)

	print('predict:', action, '\n')
	# print('mean:', mean)
	# print('std:', variance, '\n')
	# print('target', target)

	actor.save('test')
	
