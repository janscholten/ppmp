source activate ddpg
# MountainCarContinuous-v0 Pendulum-v0 LunarLanderContinuous-v2 BipedalWalker-v2
ENVS=( "Pendulum-v0")
STUDY=$(basename $0 | head -c -4)
TS=_$(date +%d%m%y%H%M)
TS=""
FILE="csv/$STUDY$TS.csv"

# Check if file is new
# echo Saving results to $FILE1
# if [ -f $FILE ]; then
#     echo "Beware for overwriting!"
#     exit 1
# fi

# If this header is not matching in myddpg.py, results will be corrupt
# echo "Environment,Seed,MultiHead,Num_heads,Source,Exploration,Average,Episode,Reward,Gain,Feedback,Autonomy" > $FILE

echo $FILE
for env in "${ENVS[@]}"; do
    while read seed; do
        echo $env
        echo $seed
        python myddpg.py --random-seed $seed --env $env --feedback human --csvlines \
        | grep CSVLINE | cut -c 9- >> $FILE
    done < studies/seeds2.txt
done
chmod -w $FILE

    # # Backup current work
    # conda list --export > conda_env.txt
    # tar -cf .backup/$STUDY.tar.gz $FILE *.py studies/$STUDY.sh conda_env.txt
    # rm conda_env.txt 
    # git add -f .backup/$STUDY.tar.gz
    # git add csv/*
    # git commit -m "Automatic commit for study '$STUDY', $(date)"
    # git pull
    # git push

echo Done