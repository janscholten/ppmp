""" 
Implementation of DDPG - Deep Deterministic Policy Gradient

Algorithm and hyperparameter details can be found here: 
    http://arxiv.org/pdf/1509.02971v2.pdf

Author: Jan Scholten, after the DDPG work of Patrick Emami
"""
# TODO: optimise this
import tensorflow as tf
import numpy as np
import pprint as pp
import matplotlib.pyplot as plt

import gym, sys, time, os
import tflearn
import argparse
import gym.spaces
from pathlib import Path

from shared_ddpg_functionalities import * #ReplayBuffer, Criticnetwork etc
from actor_networks import MultiHeadActorTarget, MultiHeadActorNoAverageTarget, Oracle
from action_selection import select_action

os.environ['TF_CPP_MIN_LOG_LEVEL'] = '3'
tf.logging.set_verbosity(tf.logging.ERROR)
gym.logger.set_level(40)

def key_press(key, mod):
    global correction, human_wants_restart, human_sets_pause
    if key==0xff0d: human_wants_restart = True
    if key==32: human_sets_pause = not human_sets_pause
    a = int( key - ord('0') )
    if a <= 0 or a > ACTIONS: return
    if a==1: a=-1
    if a==2: a=1
    correction = np.array([[a]])

def key_release(key, mod):
    global correction
    a = int( key - ord('0') )
    if a <= 0 or a > ACTIONS: return
    if a==1: a=-1
    if a==2: a=1
    if correction == a:
        correction = np.array([[0]])

# ===========================
#   Agent Training
# ===========================


def train(sess, env, args, actor, critic, oracle, actor_noise):
    sess.run(tf.global_variables_initializer())
    actor.update_target_network()
    critic.update_target_network()
    replay_buffer = ReplayBuffer(int(args['buffer_size']), int(args['random_seed']))

    global correction, human_sets_pause
    correction = np.array([[0]]) # TODO: more dims
    human_sets_pause = True if args['feedback']=='human' else False
    global ACTIONS
    ACTIONS = 2; # TODO: env

    # Needed to enable BatchNorm.
    # This hurts the performance on Pendulum but could be useful
    # in other environments.
    # tflearn.is_training(True)

    for i in range(int(args['max_episodes'])):
        s = env.reset()
        actor.change_current_head()
        ep_reward = 0
        ep_ave_max_q = 0
        gainbuffer = np.empty((int(args['max_episode_len']),actor.a_dim))*np.nan
        fb_buffer = np.zeros((int(args['max_episode_len']),actor.a_dim))
        if args['render_env']:  
            env.render()
            if args['feedback']=='human':
                env.unwrapped.viewer.window.on_key_press = key_press
                env.unwrapped.viewer.window.on_key_release = key_release

        for j in range(int(args['max_episode_len'])):

            if args['render_env']:  
                env.render()

            while human_sets_pause:
                env.render()
                time.sleep(0.1)

            # TODO: a_mean isn't the right name for a
            a_mean, a_cov = actor.policy(np.reshape(s, (1, actor.s_dim)))
            correction *= 0
            if args['feedback']=='oracle':
                if np.random.random() < .9-((i-30)/(135)):
                    correction = oracle.correct(np.reshape(s, (1, actor.s_dim)), a_mean)
            a, gain = select_action(a_mean, a_cov, correction, scale=oracle.scale, 
                offset=oracle.offset, h_cov=np.array([np.tile(float(args['human_variance']), actor.a_dim)]), 
                fashion='kalman')
            # TODO: oracle.scale is a poor place to store scale
            
            a += actor_noise()
            a = np.clip(a, env.action_space.low, env.action_space.high) # Because noise and hf

            gainbuffer[j] = np.diag(gain)
            fb_buffer[j] = correction
            # print('Heads=', actor.k, '\t Mean=', a_mean, '\t std=', a_cov, 'gain', gain)

            s2, r, terminal, info = env.step(a[0])

            replay_buffer.add(np.reshape(s, (actor.s_dim,)), \
                np.reshape(a, (actor.a_dim,)), \
                r, terminal, np.reshape(s2, (actor.s_dim,)))

            if replay_buffer.size() > int(args['minibatch_size']):
                s_batch, a_batch, r_batch, t_batch, s2_batch = \
                    replay_buffer.sample_batch(int(args['minibatch_size']))

                # Calculate targets
                target_q = critic.predict_target(
                    s2_batch, actor.policy_target(s2_batch))

                y_i = []
                for k in range(int(args['minibatch_size'])):
                    if t_batch[k]:
                        y_i.append(r_batch[k])
                    else:
                        y_i.append(r_batch[k] + critic.gamma * target_q[k])

                # Update the critic given the targets
                predicted_q_value, _ = critic.train(
                    s_batch, a_batch, np.reshape(y_i, (int(args['minibatch_size']), 1)))
                ep_ave_max_q += np.amax(predicted_q_value)

                a_outs = actor.predict(s_batch)
                grads = np.array(critic.action_gradients(
                                    s_batch.repeat(actor.k, axis=0), a_outs.reshape(-1, actor.a_dim))).squeeze()

                # grads = np.diag(np.random.random(grads.shape[0])<.20)@grads
                # grads = np.array([np.random.random(grads.shape[0])<.5]).T*grads

                actor.train(s_batch, np.reshape(grads,(-1, actor.a_dim*actor.k)))
                actor.update_target_network()
                critic.update_target_network()

            s = s2
            ep_reward += r
            if terminal:
                break

        fbtot = np.count_nonzero(fb_buffer)/fb_buffer.shape[1]/(j+1)
        print(csvformatter.format(args['env'], args['tau'], 
              args['feedback'], i, str(int(ep_reward)), 
              '{:1.4f}'.format(np.nanmean(gainbuffer)), 
              '{:1.4f}'.format(fbtot)))

def main(args):
    global csvformatter
    csvformatter = '{:<'+str(max(27,len(args['env'])+3))+ \
        '}{:<'+str(max(6,len(str(args['random_seed']))+3))+ \
        '}{:<'+str(max(8,len(args['feedback'])+3))+ \
        '}{:<10}{:<8}{:<8}{}'

    if args['header']:
        print(csvformatter.format('Environment','Tau','Source','Episode','Reward','Gain','Feedback'))

    with tf.Session() as sess:
        env = gym.make(args['env'])
        np.random.seed(int(args['random_seed']))
        tf.set_random_seed(int(args['random_seed']))
        env.seed(int(args['random_seed']))

        state_dim = env.observation_space.shape[0]
        action_dim = env.action_space.shape[0]
        action_bound = np.array([env.action_space.low, env.action_space.high])
        
        if 'oracle' in args['feedback']:
            offset = .5*action_bound.max(0)
            scale = action_bound.max(0)
            oracle = Oracle(args['env'], offset, scale)
        else:
            oracle = None

        # actor = MultiHeadActorNoAverageTarget(sess, state_dim, action_dim, action_bound,
        actor = MultiHeadActorTarget(sess, state_dim, action_dim, action_bound,
                             float(args['actor_lr']), float(args['tau']),
                             int(args['minibatch_size']), k=int(args['heads']), 
                             initial_variance=float(args['initial_variance']))

        critic = CriticNetwork(sess, state_dim, action_dim,
                               float(args['critic_lr']), float(args['tau']),
                               float(args['gamma']),
                               actor.get_num_trainable_vars())

        actor_noise = OrnsteinUhlenbeckActionNoise(mu=np.zeros(action_dim))

        if args['use_gym_monitor']:
            if not args['render_env']:
                env = wrappers.Monitor(
                    env, args['monitor_dir'], video_callable=False, force=True)
            else:
                env = wrappers.Monitor(env, args['monitor_dir'], force=True)

        train(sess, env, args, actor, critic, oracle, actor_noise)

        if args['use_gym_monitor']:
            env.monitor.close()
        del oracle
        if args['save']:
            try:
                actor.save(args['env'])
                print('Oracle saved: oracles/',args['env'])
            except:
                actor.save(args['env']+time.asctime())
                print('Oracle existed: this one is saved as oracles/',args['env']+time.asctime())

if __name__ == '__main__':
    parser = argparse.ArgumentParser(
        description='Provide arguments for DDPG agent. It should make a bit of sense, \
        arguments are not checked for mutual exclusiveness.')

    # agent parameters
    parser.add_argument('--actor-lr', help='actor network learning rate', default=0.0001)
    parser.add_argument('--critic-lr', help='critic network learning rate', default=0.001)
    parser.add_argument('--gamma', help='discount factor for critic updates', default=0.99)
    parser.add_argument('--tau', help='soft target update parameter', default=0.001)
    parser.add_argument('--buffer-size', help='max size of the replay buffer', default=1000000)
    parser.add_argument('--minibatch-size', help='size of minibatch for minibatch-SGD', default=64)
    # parser.add_argument('--exploration-noise', help='Additive. Either "none", "OU", "Sample" or "OU-Sample"', default='OU')
    parser.add_argument('--feedback', help='Either none, human or oracle', default='oracle') # TODO: call this 'Source'
    parser.add_argument('--heads', help='number of heads for multihead', default=10)
    parser.add_argument('--initial-variance', help='Initial variance of actor network ouput layer (between heads)', default=0.2)
    parser.add_argument('--human-variance', help='Human feedback variance (action domain)', default=0.001)

    # run parameters
    parser.add_argument('--env', help='choose the gym env- tested on {Pendulum-v0}', default='Pendulum-v0')
    parser.add_argument('--random-seed', help='random seed for repeatability', default=1234)
    parser.add_argument('--max-episodes', help='max num of episodes to do while training', default=200)
    parser.add_argument('--max-episode-len', help='max length of 1 episode', default=1000)
    parser.add_argument('--render-env', help='render the gym env', action='store_true')
    parser.add_argument('--use-gym-monitor', help='record gym results', action='store_true')
    parser.add_argument('--monitor-dir', help='directory for storing gym results', default='./gym_results/gym_ddpg')
    parser.add_argument('--save', help='save the actor network', action='store_true')
    parser.add_argument('--header', help='output a CSVLINE header', action='store_true')

    # TODO: fix multihead to no-multihead
    parser.set_defaults(use_gym_monitor=False)
    parser.set_defaults(render_env=False)
    parser.set_defaults(csvlines=False)
    parser.set_defaults(header=False)
    parser.set_defaults(save=False)

    # TODO: Only parse relevant args, hardcore rest at top of main() and explain hardcoding
    args = vars(parser.parse_args())
    args['render_env'] = True if args['feedback']=='human' else args['render_env']
    
    pp.pprint(args, stream=sys.stderr)
    print('\n', file=sys.stderr)

    main(args)
