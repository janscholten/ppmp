# MountainCarContinuous-v0 Pendulum-v0 LunarLanderContinuous-v2 BipedalWalker-v2
ENVS=( "MountainCarContinuous-v0" )
STUDY=$(basename $0 | head -c -4)
DATE=$(date +%d%m%y%H%M)
APPENDIX="target7"
FILE="csv/$STUDY$APPENDIX.csv"

# Check if file is new
echo Saving results to $FILE
if [ -f $FILE ]; then echo "Beware for overwriting!"; exit 1; fi

HEADER=$(python -u myddpg.py --header | grep --line-buffered Environment 2>/dev/null & $(sleep 15; kill %1))

for env in "${ENVS[@]}"; do
    while read seed; do

        python -u myddpg.py --random-seed $seed --env $env --max-episodes 700 \
        --actor-lr 0.00002 --tau 0.01 --human-variance 0.000001 --initial-variance 0.001 \
         > >(tee csv/subfiles/$STUDY\_$DATE\_$env\_$seed.csv) 2> >(tee -ap csv/subfiles/log/$STUDY\_$DATE.log >&2) &

    done < studies/seeds.txt
done
wait

echo $HEADER > $FILE
cat csv/subfiles/$STUDY\_$DATE* >> $FILE
chmod -w $FILE

# Backup current work
conda list --export > conda_env.txt
tar -cf .backup/$STUDY.tar.gz $FILE *.py studies/$STUDY.sh conda_env.txt
rm conda_env.txt 
git add -f .backup/$STUDY.tar.gz; git add csv/*
git commit -m "Automatic commit for study '$STUDY', $(date)"

echo Done
