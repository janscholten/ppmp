import matplotlib.pyplot as plt
import seaborn as sns
import pandas as pd

plt.style.use('seaborn')

# Colums: Environment, Episode, Reward, Seed, MultiHead, Num_heads, Feedback, Exploration, KalmanGain

			# Title 				dataset
# study = ['DDPG vs MultiHead', 	'ddpg_vs_mh']
# res1 = pd.read_csv('csv/'+study[1]+'.csv')
# palette = sns.color_palette("mako_r", 2)
# sns.lineplot(x='Episode', y='Reward', data=res1, 
# 	hue='MultiHead', legend='brief', palette=palette)
# plt.title(study[0]+' (Pendulum-v0), n=10')
# plt.savefig('graphics/' + study[0] +'.pdf')

# study = ['Number of Heads', 	'num_heads']
# plt.cla()
# res2 = pd.read_csv('csv/'+study[1]+'.csv')
# palette = sns.color_palette("mako_r", 6)
# sns.lineplot(x='Episode', y='Reward', data=res2, 
# 	hue='Num_heads', palette=palette)
# plt.title(study[0]+' (Pendulum-v0), n=5')
# plt.savefig('graphics/' + study[0] +'.pdf')

# study = ['Number of Heads (no hue)', 	'num_heads']
# plt.cla()
# res3 = pd.read_csv('csv/'+study[1]+'.csv')
# palette = sns.color_palette("mako_r", 6)
# sns.lineplot(x='Episode', y='Reward', data=res3, 
# 	hue='Num_heads', legend='full', err_style=None, palette=palette)
# plt.title(study[0]+' (Pendulum-v0), n=5')
# plt.savefig('graphics/' + study[0] +'.pdf')

# study = ['Execution time of MultiHead', 	'time_num_heads_aws']
# plt.cla()
# res4 = pd.read_csv('csv/'+study[1]+'.csv')
# sns.boxplot(x='Num_heads', y='Time', data=res4)
# plt.title(study[0]+' (Pendulum-v0), n=10')
# plt.ylabel('Time [s]')
# plt.savefig('graphics/' + study[0] +'.pdf')

# study = ['Kalman vs Reference', 	'kalman']
# plt.cla()
# res5 = pd.read_csv('csv/'+study[1]+'_0809181253.csv')
# palette = sns.color_palette("mako_r", 5)
# sns.lineplot(x='Episode', y='Reward', data=res5, hue='Seed', estimator=None, style='Feedback', palette=palette)
# plt.title(study[0]+' (MountainCarContinuous-v0), n=5')
# plt.savefig('graphics/' + study[0] +'.pdf')

# study = ['Gain vs Reward', 	'kalman']
# plt.cla()
# res6 = pd.read_csv('csv/'+study[1]+'_0809181253.csv')
# palette = sns.color_palette("mako_r", 5)
# sns.scatterplot(x='Reward', y='KalmanGain', data=res6, hue='Seed', 
# 	legend='full', palette=palette)
# plt.title(study[0]+' (MountainCarContinuous-v0), n=5')
# plt.savefig('graphics/' + study[0] +'.pdf')

# study = ['Gain vs Episodes', 	'kalman']
# plt.cla()
# res7 = pd.read_csv('csv/'+study[1]+'_0809181253.csv')
# palette = sns.color_palette("mako_r", 5)
# sns.lineplot(x='Episode', y='KalmanGain', hue='Seed', style='Feedback', data=res7, palette=palette, legend='full')
# plt.title(study[0]+' (MountainCarContinuous-v0), n=5')
# plt.savefig('graphics/' + study[0] +'.pdf')

# study = ['MultiHead (Pendulum-v0)', 	'mh_ou_pd']
# plt.cla()
# res8 = pd.read_csv('csv/'+study[1]+'.csv')
# palette = sns.color_palette("mako_r", 2)
# sns.lineplot(x='Episode', y='Reward', hue='MultiHead', data=res8, palette=palette)
# plt.title(study[0]+', n=10')
# plt.savefig('graphics/' + study[0] +'.pdf')

# study = ['Using Additive Noise (Pendulum-v0)', 	'mh_ou_pd']
# plt.cla()
# res8 = pd.read_csv('csv/'+study[1]+'.csv')
# palette = sns.color_palette("mako_r", 2)
# sns.lineplot(x='Episode', y='Reward', hue='Exploration', data=res8, palette=palette)
# plt.title(study[0]+', n=10')
# plt.savefig('graphics/' + study[0] +'.pdf')

# study = ['Exploration Strategies (MountainCarContinuous-v0)', 	'mh_ou_mc']
# plt.cla()
# res9 = pd.read_csv('csv/'+study[1]+'.csv')
# palette = sns.color_palette("mako_r", 2)
# sns.lineplot(x='Episode', y='Reward', hue='MultiHead', style='Exploration', data=res9, palette=palette)
# plt.title(study[0]+', n=5')
# plt.savefig('graphics/' + study[0] +'.pdf')

# study = ['Runs (MountainCarContinuous-v0)', 	'mh_ou_mc']
# plt.cla()
# res9 = pd.read_csv('csv/'+study[1]+'.csv')
# palette = sns.color_palette("mako_r", 2)
# sns.lineplot(x='Episode', y='Reward', hue='MultiHead', style='Seed', data=res9.loc[res9.Exploration=='OU'], palette=palette)
# plt.title(study[0]+', n=5')
# plt.savefig('graphics/' + study[0] +'.pdf')

# study = ['Exploration Strategies (Pendulum-v0)', 	'mh_ou_pd']
# plt.cla()
# res99 = pd.read_csv('csv/'+study[1]+'.csv')
# palette = sns.color_palette("mako_r", 2)
# sns.lineplot(x='Episode', y='Reward', hue='MultiHead', style='Exploration', data=res99, palette=palette)
# plt.title(study[0]+', n=10')
# plt.savefig('graphics/' + study[0] +'.pdf')

# study = ['Reward vs Gain (MountainCarContinuous-v0)', 	'mh_ou_mc']
# res10 = pd.read_csv('csv/'+study[1]+'.csv')
# plt.clf()
# ax1 = plt.subplot(221)
# sns.distplot(res10.loc[res10.Exploration=='OU'].Reward, norm_hist=True)
# ax3 = plt.subplot(223)
# sns.regplot(x='Reward', y='KalmanGain', data=res10.loc[res10.Exploration=='OU'])
# ax4 = plt.subplot(224)
# sns.distplot(res10.loc[res10.Exploration=='OU'].KalmanGain,vertical=True, norm_hist=True)
# ax1.set_xlim(ax3.get_xlim())
# ax1.get_xaxis().set_visible(False)
# ax4.set_ylim(ax3.get_ylim())
# ax4.get_yaxis().set_visible(False)
# plt.suptitle(study[0]+', n=5')
# plt.savefig('graphics/' + study[0] +'.pdf')

# study = ['Reward vs Gain (Pendulum-v0)', 	'mh_ou_pd']
# res11 = pd.read_csv('csv/'+study[1]+'.csv')
# plt.clf()
# ax1 = plt.subplot(221)
# sns.distplot(res11.Reward, norm_hist=True)
# ax3 = plt.subplot(223)
# sns.regplot(x='Reward', y='KalmanGain', data=res11)
# ax4 = plt.subplot(224)
# sns.distplot(res11.KalmanGain, vertical=True, norm_hist=True)
# ax1.set_xlim(ax3.get_xlim())
# ax1.get_xaxis().set_visible(False)
# ax4.set_ylim(ax3.get_ylim())
# ax4.get_yaxis().set_visible(False)
# plt.suptitle(study[0]+', n=10')
# plt.savefig('graphics/' + study[0] +'.pdf')

# study = ['Reward vs Gain, HF (MountainCarContinuous-v0)', 	'kalman']
# res12 = pd.read_csv('csv/'+study[1]+'_0809181253.csv')
# plt.clf()
# ax1 = plt.subplot(221)
# # cant plot the next one because it's zeros()
# # sns.distplot(res12.loc[res12.Feedback=='none'].Reward, kde=False, norm_hist=True)
# sns.distplot(res12.loc[res12.Feedback=='human'].Reward, norm_hist=True)
# ax3 = plt.subplot(223)
# sns.regplot(x='Reward', y='KalmanGain', data=res12.loc[res12.Feedback=='human'])
# sns.regplot(x='Reward', y='KalmanGain', data=res12.loc[res12.Feedback=='none'])
# ax4 = plt.subplot(224)
# sns.distplot(res12.loc[res12.Feedback=='human'].KalmanGain,vertical=True, label='human')
# sns.distplot(res12.loc[res12.Feedback=='none'].KalmanGain,vertical=True, label='none')
# plt.legend()
# ax1.set_xlim(ax3.get_xlim())
# ax1.get_xaxis().set_visible(False)
# ax4.set_ylim(ax3.get_ylim())
# ax4.get_yaxis().set_visible(False)
# plt.suptitle(study[0]+', n=5')
# plt.savefig('graphics/' + study[0] +'.pdf')

# study = ['Averaging (Pendulum-v0), n=10', 	'average']
# plt.cla()
# res9 = pd.read_csv('csv/'+study[1]+'.csv')
# sns.lineplot(x='Episode', y='Reward', data=res9.loc[res9.Environment=='Pendulum-v0'] , hue='Average', legend='full')
# plt.title(study[0]); plt.savefig('graphics/' + study[0] +'.pdf')

# study = ['Averaging (MountainCarContinuous-v0), n=10', 	'mount700']
# plt.cla()
# res9 = pd.read_csv('csv/'+study[1]+'.csv')
# sns.lineplot(x='Episode', y='Reward', data=res9.iloc[1:-1:10] , hue='Average', legend='full')
# plt.title(study[0]); plt.savefig('graphics/' + study[0] +'.pdf')

# study = ['MultiHead (LunarLanderContinuous-v2), n=10', 	'envs']
# plt.cla()
# res9 = pd.read_csv('csv/'+study[1]+'.csv')
# sns.lineplot(x='Episode', y='Reward', data=res9.loc[res9.Environment=='LunarLanderContinuous-v2'].iloc[1:-1:10])
# plt.title(study[0]); plt.savefig('graphics/' + study[0] +'.pdf')

# study = ['MultiHead (BipedalWalker-v2), n=10', 	'envs']
# plt.cla()
# res9 = pd.read_csv('csv/'+study[1]+'.csv')
# sns.lineplot(x='Episode', y='Reward', data=res9.loc[res9.Environment=='BipedalWalker-v2'].iloc[1:-1:10])
# plt.title(study[0]); plt.savefig('graphics/' + study[0] +'.pdf')

# study = ['Gain (MountainCarContinuous-v0), n=10', 	'mount700']
# plt.cla()
# res9 = pd.read_csv('csv/'+study[1]+'.csv').iloc[1:-1:4]
# res8 = pd.read_csv('csv/average.csv')
# res9 = res9.append(res8)
# sns.lineplot(x='Episode', y='KalmanGain', data=res9.loc[res9.Average=='False'], hue='Environment')
# plt.title(study[0]); 
# plt.show()
# # plt.savefig('graphics/' + study[0] +'.pdf')

study = ['Oracle and Human (Pendulum-v0), n=1', 	'shorthuman']
plt.cla()
res1 = pd.read_csv('csv/'+study[1]+'.csv')
sns.lineplot(x='Episode', y='Gain', data=res1, hue='Source')
plt.title(study[0]); 
plt.show()
# plt.savefig('graphics/' + study[0] +'.pdf')

# study = ['Human (Pendulum-v0), n=10', 	'human']
# plt.cla()
# res1 = pd.read_csv('csv/'+study[1]+'.csv')
# sns.lineplot(x='Episode', y='Reward', data=res1, hue='Source')
# plt.show()
# plt.title(study[0]); plt.savefig('graphics/' + study[0] +'.pdf')
