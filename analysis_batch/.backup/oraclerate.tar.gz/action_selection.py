
import numpy as np
import pandas as pd
import seaborn as sns
import matplotlib.pyplot as plt
import scipy.stats

# plt.style.use('ggplot')
plt.style.use('seaborn')

# TODO: make this
# class ActionSelector(object):
# 	"""Select an action"""
# 	def __init__(self, arg):
# 		super(ActionSelector, self).__init__()
# 		self.arg = arg


def select_action(a_mean, a_cov, h, h_cov, fashion='kalman', offset=0, plot=False, ax = []):
	C = np.eye(a_mean.shape[1])
	gain = a_cov@(C.T)@np.linalg.inv(C@a_cov@(C.T) + h_cov)  + offset
	action = a_mean + gain@h
		# variance = a_cov - gain@C@a_cov
		# if plot: 
			# plot_pdf_combination(a, b, [action, variance], ax)
	return action, gain


# def discretize_gaussian(a, resolution):
# 	width = 4 # times sigma
# 	x = np.linspace(a[0]-width*a[1], a[0]+width*a[1], resolution)
# 	return x, scipy.stats.norm(a[0], a[1]).pdf(x)

# def plot_pdf_combination(a, b, c, ax):
# 	# Here we need to plot in global AX if it exists. Else, make a plot in the wild
# 	if not ax:
# 		fig = plt.figure()
# 		ax = fig.add_subplot(111)
# 	resolution = 35
	
# 	Ax, A = discretize_gaussian(a, resolution)
# 	Bx, B = discretize_gaussian(b, resolution)
# 	Cx, C = discretize_gaussian(c, resolution)

# 	plt.sca(ax)
# 	plt.fill(Ax, A, Bx, B, Cx, C)
# 	plt.legend(["Policy", "Human Feedback", "Combination"])
# 	plt.ylim(ymin=0)
# 	plt.ylabel("Probability Density")
# 	plt.xlabel("x")
# 	plt.show()




# seaborn stuff, fancy but uncomprehensible
# 	x = np.concatenate((A,B,C))
# 	print(A)
# 	print(B)
# 	print(C)
# 	print(x)
# 	g = np.sort(np.tile(list("ABC"), resolution))
# 	# print(g)
# 	df = pd.DataFrame(dict(x=x, g=g))	


# 	# Initialize the FacetGrid object
# 	sns.set(style="white", rc={"axes.facecolor": (0, 0, 0, 0)})
# 	pal = sns.cubehelix_palette(10, rot=-.25, light=.7)
# 	g = sns.FacetGrid(df, row="g", hue="g", aspect=15, height=.5, palette=pal)

# 	# Draw the densities in a few steps
# 	g.map(sns.kdeplot, "x", clip_on=False, shade=True, alpha=1, lw=1.5, bw=.2)
# 	g.map(sns.kdeplot, "x", clip_on=False, color="w", lw=2, bw=.2)
# 	g.map(plt.axhline, y=0, lw=2, clip_on=False)

# 	g.map(label, "x")

# 	# Set the subplots to overlap
# 	g.fig.subplots_adjust(hspace=-.25)

# 	# Remove axes details that don't play well with overlap
# 	g.set_titles("")
# 	g.set(yticks=[])
# 	g.despine(bottom=True, left=True)
# 	plt.show()

# # Define and use a simple function to label the plot in axes coordinates
# def label(x, color, label):
#     ax = plt.gca()
#     ax.text(0, .2, label, fontweight="bold", color=color,
#             ha="left", va="center", transform=ax.transAxes)

# AND THE ORIGINAL SEABORN RIDGE PLOT CODE:
"""
Overlapping densities ('ridge plot')
====================================


# """
# import numpy as np
# import pandas as pd
# import seaborn as sns
# import matplotlib.pyplot as plt
# sns.set(style="white", rc={"axes.facecolor": (0, 0, 0, 0)})

# # Create the data
# rs = np.random.RandomState(1979)
# x = rs.randn(500)
# g = np.tile(list("ABCDEFGHIJ"), 50)
# df = pd.DataFrame(dict(x=x, g=g))
# m = df.g.map(ord)
# df["x"] += m

# # Initialize the FacetGrid object
# pal = sns.cubehelix_palette(10, rot=-.25, light=.7)
# g = sns.FacetGrid(df, row="g", hue="g", aspect=15, height=.5, palette=pal)

# # Draw the densities in a few steps
# g.map(sns.kdeplot, "x", clip_on=False, shade=True, alpha=1, lw=1.5, bw=.2)
# g.map(sns.kdeplot, "x", clip_on=False, color="w", lw=2, bw=.2)
# g.map(plt.axhline, y=0, lw=2, clip_on=False)


# # Define and use a simple function to label the plot in axes coordinates
# def label(x, color, label):
#     ax = plt.gca()
#     ax.text(0, .2, label, fontweight="bold", color=color,
#             ha="left", va="center", transform=ax.transAxes)


# g.map(label, "x")

# # Set the subplots to overlap
# g.fig.subplots_adjust(hspace=-.25)

# # Remove axes details that don't play well with overlap
# g.set_titles("")
# g.set(yticks=[])
# g.despine(bottom=True, left=True)
# plt.show()