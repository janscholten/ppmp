import tflearn
import tensorflow as tf
import numpy as np
from tensorflow.python.saved_model import tag_constants
from pathlib import Path

class DefaultActor(object):
    """
    Input to the network is the state, output is the action
    under a deterministic policy.

    The output layer activation is a tanh to keep the action
    between -action_bound and action_bound
    """

    def __init__(self, sess, state_dim, action_dim, action_bound, learning_rate, tau, batch_size):
        self.sess = sess
        self.s_dim = state_dim
        self.a_dim = action_dim
        self.action_bound = action_bound
        self.variance = np.array([[1]]) # TODO: make this a **kwars??
        self.learning_rate = learning_rate
        self.tau = tau
        self.batch_size = batch_size
        self.k = 1

        # Actor Network
        self.inputs, self.out, self.scaled_out = self.create_actor_network()

        self.network_params = tf.trainable_variables()

        # Target Network
        self.target_inputs, self.target_out, self.target_scaled_out = self.create_actor_network()

        self.target_network_params = tf.trainable_variables()[
            len(self.network_params):]

        # Op for periodically updating target network with online network
        # weights
        self.update_target_network_params = \
            [self.target_network_params[i].assign(tf.multiply(self.network_params[i], self.tau) +
                                                  tf.multiply(self.target_network_params[i], 1. - self.tau))
                for i in range(len(self.target_network_params))]

        # This gradient will be provided by the critic network
        self.action_gradient = tf.placeholder(tf.float32, [None, self.a_dim])

        # Combine the gradients here
        self.unnormalized_actor_gradients = tf.gradients(
            self.scaled_out, self.network_params, -self.action_gradient)
        self.actor_gradients = list(map(lambda x: tf.div(x, self.batch_size), self.unnormalized_actor_gradients))

        # Optimization Op
        self.optimize = tf.train.AdamOptimizer(self.learning_rate).\
            apply_gradients(zip(self.actor_gradients, self.network_params))

        self.num_trainable_vars = len(
            self.network_params) + len(self.target_network_params)

    def create_actor_network(self):
        inputs = tflearn.input_data(shape=[None, self.s_dim])
        net = tflearn.fully_connected(inputs, 400)
        net = tflearn.layers.normalization.batch_normalization(net)
        net = tflearn.activations.relu(net)
        net = tflearn.fully_connected(net, 300)
        net = tflearn.layers.normalization.batch_normalization(net)
        net = tflearn.activations.relu(net)
        # Final layer weights are init to Uniform[-3e-3, 3e-3]
        w_init = tflearn.initializations.uniform(minval=-0.003, maxval=0.003)
        out = tflearn.fully_connected(
            net, self.a_dim, activation='tanh', weights_init=w_init)
        
        # Scale output to -action_bound to action_bound
        num_heads = int(self.a_dim/len(self.action_bound[0].flatten())) # misleading because of init
        bounds = np.tile(np.abs(self.action_bound).max(axis=0), num_heads)
        min = np.tile(self.action_bound[0], num_heads)
        max = np.tile(self.action_bound[1], num_heads)
        scaled_out = tf.clip_by_value(tf.multiply(out, bounds), min, max)
        return inputs, out, scaled_out

    def train(self, inputs, a_gradient):
        self.sess.run(self.optimize, feed_dict={
            self.inputs: inputs,
            self.action_gradient: a_gradient
        })

    def predict(self, inputs):
        return self.sess.run(self.scaled_out, feed_dict={
            self.inputs: inputs
        })

    def predict_target(self, inputs):
        return self.sess.run(self.target_scaled_out, feed_dict={
            self.target_inputs: inputs
        })

    def update_target_network(self):
        self.sess.run(self.update_target_network_params)

    def get_num_trainable_vars(self):
        return self.num_trainable_vars

    def policy(self, inputs):
        a = self.predict(inputs)
        return a, self.variance

    def policy_target(self, inputs):
        return self.predict_target(inputs)

    def save(self, filename):
        tf.saved_model.simple_save(self.sess,
                    "./oracles/"+filename,
                    inputs={"state": self.inputs},
                    outputs={"out": self.scaled_out})
        return



class MultiHeadActor(DefaultActor):
    """Inherits fron ActorNetwork. Last layer is duplicated k times, so it will output k action suggestions. 
    There is a policy() method that outputs the mean action and std"""
    
    # Heads are stacked in columns, as rows correspond to samples
    def __init__(self, sess, state_dim, action_dim, action_bound, learning_rate, tau, batch_size, k):
        super().__init__(sess, state_dim, action_dim*k, action_bound, learning_rate, tau, batch_size)
        
        # Because base class beliefs a_dim = actual_a_dim*k:
        self.a_dim = action_dim
        self.k = k

    def policy(self, inputs):
        # multihead is stacked columnwise
        a = np.array(np.hsplit(self.predict(inputs), self.k))
        return a.mean(0), a.std(0)

    def policy_target(self, inputs):
        a = np.array(np.hsplit(self.predict_target(inputs), self.k))
        return a.mean(0)

class MultiHeadActorNoAverage(MultiHeadActor):
    """This Multihead actor outputs a policy that corresponds to a single head. 
    The actor.current_head value can be randomly set,
     e.g. every episode by calling actor.change_current_head()"""
    def __init__(self, sess, state_dim, action_dim, action_bound, learning_rate, tau, batch_size, k):
        super().__init__(sess, state_dim, action_dim, action_bound, learning_rate, tau, batch_size, k)
        self.change_current_head()

    def policy(self, inputs):
        a = np.array(np.hsplit(self.predict(inputs), self.k))
        return a[self.current_head,:,:], a.std(0)

    def policy_target(self, inputs):
        # TODO: Think about always having a random active head, or using self.current_head for the whole batch
        return np.array(np.hsplit(self.predict_target(inputs), self.k))[np.random.random_integers(self.k)-1,:,:]

    def change_current_head(self):
        self.current_head = np.random.random_integers(self.k) - 1

class Oracle(object):
    """Will restore a tf graph from disk, 
    and provides a policy() method which returns the optimal action"""
    def __init__(self, env):
        dir = Path('oracles/' + env)
        assert dir.is_dir(), 'There was no oracle found'
        self.graph = tf.Graph()
        # with tf.Session(graph=self.graph) as self.sess: # cumbersome
        self.sess = tf.Session(graph=self.graph)         # but now we need 'del oracle'
        tf.saved_model.loader.load(self.sess, [tag_constants.SERVING], "./oracles/"+env)
        self.scaled_out_ph = self.graph.get_tensor_by_name('clip_by_value:0')
        self.inputs_ph = self.graph.get_tensor_by_name('InputData/X:0')

    def predict(self, states):
        return self.sess.run(self.scaled_out_ph, feed_dict={self.inputs_ph : states}) 

    def correct(self, state, action):
        should = self.predict(state)
        diff = should - action
        correction = np.sign(diff)*np.sign(np.round(np.abs(diff)+0.25))
        # print('Het Orakel spreekt:', diff, correction)
        return correction

    def __del__(self):
        self.sess.close()
