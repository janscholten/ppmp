import matplotlib.pyplot as plt
import seaborn as sns
import pandas as pd

plt.style.use('seaborn')

# Colums: Environment, Episode, Reward, Seed, MultiHead, Num_heads, Feedback

			# Title 				dataset
# study = ['DDPG vs MultiHead', 	'ddpg_vs_mh']
# res1 = pd.read_csv('csv/'+study[1]+'.csv')
# palette = sns.color_palette("mako_r", 2)
# sns.lineplot(x='Episode', y='Reward', data=res1, 
# 	hue='MultiHead', legend='brief', palette=palette)
# plt.title(study[0]+' (Pendulum-v0), n=10')
# plt.savefig('graphics/' + study[0] +'.pdf')

# study = ['Number of Heads', 	'num_heads']
# plt.cla()
# res2 = pd.read_csv('csv/'+study[1]+'.csv')
# palette = sns.color_palette("mako_r", 6)
# sns.lineplot(x='Episode', y='Reward', data=res2, 
# 	hue='Num_heads', palette=palette)
# plt.title(study[0]+' (Pendulum-v0), n=5')
# plt.savefig('graphics/' + study[0] +'.pdf')

# study = ['Number of Heads (no hue)', 	'num_heads']
# plt.cla()
# res3 = pd.read_csv('csv/'+study[1]+'.csv')
# palette = sns.color_palette("mako_r", 6)
# sns.lineplot(x='Episode', y='Reward', data=res3, 
# 	hue='Num_heads', legend='full', err_style=None)#, palette=palette)
# plt.title(study[0]+' (Pendulum-v0), n=5')
# plt.savefig('graphics/' + study[0] +'.pdf')
# plt.show()			

# study = ['Execution time of MultiHead', 	'time_num_heads']
# plt.cla()
# res4 = pd.read_csv('csv/'+study[1]+'_3108181528.csv')
# res4 = pd.read_csv('csv/'+study[1]+'.csv')
# palette = sns.color_palette("mako_r", 6)
# sns.boxplot(x='Num_heads', y='Time', data=res4)#, palette=palette)
# plt.title(study[0]+' (Pendulum-v0), n=10')
# plt.ylabel('Time [s]')
# plt.savefig('graphics/' + study[0] +'.pdf')


# study = ['Human Feedback, Kalman style', 	'kalman']
# plt.cla()
# res5 = pd.read_csv('csv/'+study[1]+'_0809181253.csv')
# # palette = sns.color_palette("mako_r", 6)
# sns.lineplot(x='Episode', y='Reward', data=res5)#, palette=palette)
# plt.title(study[0]+' (MountainCarContinuous-v0), n=5')
# plt.savefig('graphics/' + study[0] +'.pdf')

study = ['Gain vs Reward', 	'kalman']
plt.cla()
res5 = pd.read_csv('csv/'+study[1]+'_0809181253.csv')
# palette = sns.color_palette("mako_r", 6)
sns.regplot(x='Reward', y='KalmanGain', data=res5, label='Seed')#, palette=palette)
plt.title(study[0]+' (MountainCarContinuous-v0), n=5')
plt.show()
# plt.savefig('graphics/' + study[0] +'.pdf')
