ENVS=( "Pendulum-v0" )
REPS=10

STUDY=$(basename $0 | head -c -4)
TS=_aws
FILE="csv/$STUDY$TS.csv"

# Check if file is new
echo Saving results to $FILE
if [ -f $FILE ]; then
    echo "Beware for overwriting!"
    exit 1
fi

# Don't fall asleep
if [ $(whoami) = "jan" ]; then
    sudo systemctl mask sleep.target suspend.target hibernate.target hybrid-sleep.target
    echo "Hi jan. Your laptop will not hibernate until I'm done"
fi

# Run, make csv
echo "Experiment,Num_heads,Time" > $FILE


for env in "${ENVS[@]}"; do
    for (( i = 0; i < $REPS; i++ )); do
        seed=$(date +%N)
        for ii in $(seq 1 15); do
            echo "Starting iteration $ii/15, rep $i/$REPS in $env"
            { /usr/bin/time -f "%e" python myddpg.py --num-heads $ii > /dev/null ; } 2> tmp.dat
            cat tmp.dat | grep [0-9] | grep -v - | echo $i,$ii,$(cat -) >> $FILE
        done
    done
done
rm tmp.dat

chmod -w $FILE

# Backup current work
conda list --export > conda_env.txt
tar -cf .backup/$STUDY.tar.gz $FILE *.py  studies/$STUDY.sh conda_env.txt
rm conda_env.txt
git add -f .backup/$STUDY.tar.gz
git add -A
git commit -m "Automatic commit for study '$STUDY', $(date)"

# Allow hibernation again
if [ $(whoami) = "jan" ]; then
    sudo systemctl unmask sleep.target suspend.target hibernate.target hybrid-sleep.target
fi

echo Done!
