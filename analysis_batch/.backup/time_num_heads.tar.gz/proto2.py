import tensorflow as tf
import numpy as np
import os, shutil, tflearn
from tensorflow.python.saved_model import tag_constants

s = np.array([[1,2]])
# Restoring
oracle_graph = tf.Graph()
with tf.Session(graph=oracle_graph) as sess_oracle:
	tf.saved_model.loader.load(sess_oracle, [tag_constants.SERVING], "./oracles/test")
	inputs_ph = oracle_graph.get_tensor_by_name('InputData/X:0')
	scaled_out_ph = oracle_graph.get_tensor_by_name('clip_by_value:0')

	# Tensor("InputData/X:0", shape=(?, 2), dtype=float32)
	# Tensor("clip_by_value:0", shape=(?, 3), dtype=float32)
	# <class 'tensorflow.python.framework.ops.Tensor'>
	# <class 'tensorflow.python.framework.ops.Tensor'>

	# sess.run(self.scaled_out_ph, feed_dict={
	# self.inputs: inputs
	# })

	mean = sess_oracle.run(scaled_out_ph, feed_dict={inputs_ph : s}) 
	print('mean:', mean)
